import json
import boto3
import urllib3
import os

sns = boto3.client('sns')

# Defina a URL do webhook do Microsoft Teams no AWS Lambda Environment Variables
TEAMS_WEBHOOK_URL = os.environ.get("TEAMS_WEBHOOK_URL")
SNS_TARGET = os.environ.get("SNS_TARGET")
def lambda_handler(event, context):
    

    """Handler principal do AWS Lambda"""
    print("Evento recebido:", json.dumps(event, indent=2))
    
    if not TEAMS_WEBHOOK_URL:
        return {"statusCode": 500, "body": "Erro: TEAMS_WEBHOOK_URL não configurada."}

    # Formata a mensagem do Security Hub
    message = format_security_hub_message(event)

    # Envia para o Microsoft Teams
    #response = send_to_teams(message)
    
    #return response


    """Formata os detalhes do evento do Security Hub para o Microsoft Teams"""
    findings = event.get("detail", {}).get("findings", [])
    print("SNS: Evento recebido:", json.dumps(event, indent=2))

    #if not findings:
    #    return "Nenhum evento do Security Hub encontrado."

    messages = []
    
    for finding in findings:
        severity = finding.get("Severity", {}).get("Label", "UNKNOWN")
        title = finding.get("Title", "Sem título")
        description = finding.get("Description", "Sem descrição disponível")
        account_id = finding.get("AwsAccountId", "Desconhecido")
        region = finding.get("Region", "Desconhecida")
        resources = finding.get("Resources", [])
        
        resource_list = "\n".join([r.get("Id", "Recurso Desconhecido") for r in resources])

        message = (            
            f"**🚨 Alerta de Segurança do Security Hub da AILOS 🚨**\n\n"
            f"🔹 **Tipo de conformidade:** NON_COMPLIANT\n\n"
            f"🔹 **Título:** {title}\n\n"
            f"🔹 **Severidade:** {severity}\n\n"
            f"🔹 **Descrição:** {description}\n\n"
            f"🔹 **Conta AWS:** {account_id}\n\n"
           # f"🔹 **Nome da Conta:** {AwsAccountName}\n\n"
            f"🔹 **Região:** {region}\n\n"
            f"🔹 **Recursos afetados:** {resource_list}\n\n"
        )
        
        messages.append(message)

    #return "\n\n".join(messages)

    #Envia para o Microsoft Teams
    response = send_to_teams(message)
       
    response = sns.publish(
            TopicArn = SNS_TARGET,
            Message = message
            )
      
    return {
      'statusCode': 200,
      'body': json.dumps('Success!')
}



#ENVIA ALERTA PARA O TEAMS

def format_security_hub_message(event):
    """Formata os detalhes do evento do Security Hub para o Microsoft Teams"""

    findings = event.get("detail", {}).get("findings", [])
    
    #if not findings:
    #    return "Nenhum evento do Security Hub encontrado."



def send_to_teams(message):
    """Envia a mensagem para o Microsoft Teams via Webhook"""
    headers = {'Content-Type': 'application/json'}
    http = urllib3.PoolManager()
    response = http.request('POST', os.environ['TEAMS_WEBHOOK_URL'], body = json.dumps(message).encode('utf-8'), headers=headers, retries = False)
    
    payload = {
        "text": message
    }
 
    
    payload = json.dumps({"text": message}).encode("utf-8")



    try:
        response = http.request("POST", TEAMS_WEBHOOK_URL, body=payload, headers=headers)
        #response = http.request('POST', os.environ['TEAMS_WEBHOOK_URL'], body = json.dumps(message).encode('utf-8'), headers=headers, retries = False)
        #response = requests.post(TEAMS_WEBHOOK_URL, headers=headers, json=payload)
        #response.raise_for_status()
        return {"statusCode": 200, "body": "Mensagem enviada para o Teams com sucesso."}
    except urllib3.exceptions.HTTPError as e:
        return {"statusCode": 500, "body": f"Erro ao enviar mensagem para o Teams: {str(e)}"}